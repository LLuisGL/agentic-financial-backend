import json
from fastapi import APIRouter, Depends, HTTPException
from sqlalchemy.orm import Session
from app import models, negociacion as negociacion_service, schemas, validations
from app.database import get_db
from app.serializers import caso_a_dict, negociacion_a_dict

router = APIRouter(prefix="/casos", tags=["casos"])

ACCIONES_CIERRE_VALIDAS = {"LIQUIDACION", "TRANSFERENCIA", "ENDOSO"}


def _registrar_evento(db: Session, caso: models.Caso, tipo: str, descripcion: str, data: dict | None = None) -> None:
    db.add(
        models.EventoCaso(
            caso_id=caso.id,
            tipo=tipo,
            descripcion=descripcion,
            data_json=json.dumps(data, default=str) if data is not None else None,
        )
    )


def _obtener_caso_o_404(db: Session, caso_id: int) -> models.Caso:
    caso = db.get(models.Caso, caso_id)
    if caso is None:
        raise HTTPException(status_code=404, detail="Caso no encontrado.")
    return caso


@router.post("")
def crear_caso(payload: schemas.CasoCrearRequest, db: Session = Depends(get_db)):
    """HU1: crea el expediente solo con los campos que el operador confirmó o editó.

    Los campos marcados como 'rechazar' no se persisten.
    """
    acciones = {c.campo: c.accion for c in payload.campos} if payload.campos else {}

    def permitido(campo: str) -> bool:
        return acciones.get(campo, "confirmar") in ("confirmar", "editar")

    cliente = db.query(models.Cliente).filter(models.Cliente.ruc_cedula == payload.ruc_cedula).first()
    if cliente is None:
        cliente = models.Cliente(
            ruc_cedula=payload.ruc_cedula,
            razon_social=payload.razon_social,
            tipo_persona=payload.tipo_persona,
            representante_legal=payload.representante_legal if permitido("representante_legal") else None,
        )
        db.add(cliente)
        db.flush()
    else:
        if payload.razon_social and permitido("razon_social"):
            cliente.razon_social = payload.razon_social
        if payload.representante_legal and permitido("representante_legal"):
            cliente.representante_legal = payload.representante_legal

    titulo = None
    if payload.numero_titulo and permitido("numero_titulo"):
        titulo = db.query(models.Titulo).filter(models.Titulo.numero_titulo == payload.numero_titulo).first()
        if titulo is None:
            titulo = models.Titulo(
                cliente_id=cliente.id,
                numero_titulo=payload.numero_titulo,
                tipo_nota=payload.tipo_nota or "NCD",
                valor_nominal=payload.valor_nominal or 0.0,
                saldo_disponible=payload.saldo_disponible if payload.saldo_disponible is not None else (payload.valor_nominal or 0.0),
                url_documento=payload.url_documento,
            )
            db.add(titulo)
            db.flush()

    caso = models.Caso(
        cliente_id=cliente.id,
        titulo_id=titulo.id if titulo else None,
        operador=payload.operador,
        estado="RECIBIDO",
        proxima_accion="Ejecutar validaciones (POST /casos/{id}/validar)",
    )
    db.add(caso)
    db.flush()

    _registrar_evento(
        db,
        caso,
        "DATO_CONFIRMADO",
        "Expediente creado a partir de datos confirmados/editados por el operador.",
        {"campos_recibidos": [c.model_dump() for c in payload.campos]},
    )

    db.commit()
    db.refresh(caso)
    return caso_a_dict(caso)


@router.get("")
def listar_casos(estado: str | None = None, ruc_cedula: str | None = None, db: Session = Depends(get_db)):
    query = db.query(models.Caso)
    if estado:
        query = query.filter(models.Caso.estado == estado)
    if ruc_cedula:
        query = query.join(models.Cliente).filter(models.Cliente.ruc_cedula == ruc_cedula)
    return [caso_a_dict(c, incluir_relaciones=False) for c in query.order_by(models.Caso.creado_en.desc()).all()]


@router.get("/{caso_id}")
def obtener_caso(caso_id: int, db: Session = Depends(get_db)):
    return caso_a_dict(_obtener_caso_o_404(db, caso_id))


@router.post("/{caso_id}/validar")
def validar_caso(caso_id: int, db: Session = Depends(get_db)):
    """HU2: valida existencia/saldo/estado/bloqueos, duplicados y riesgo; sugiere el siguiente paso."""
    caso = _obtener_caso_o_404(db, caso_id)
    resultado = validations.validar_caso(db, caso)

    caso.estado = "EN_VALIDACION" if resultado["pendientes"] else "VALIDADO"
    accion_legible = {
        "SOLICITAR_DOCUMENTO": "Solicitar documento faltante al cliente",
        "ACTUALIZAR_DATO": "Actualizar dato con el operador",
        "ENVIAR_A_CUMPLIMIENTO": "Enviar a cumplimiento para revisión",
        "PREPARAR_ORDEN": "Preparar orden de negociación",
        "CONTINUAR": "Continuar con negociación (POST /casos/{id}/negociacion/propuesta)",
    }[resultado["siguiente_accion_sugerida"]]
    caso.proxima_accion = accion_legible

    _registrar_evento(db, caso, "VALIDACION", f"Validación ejecutada: {len(resultado['pendientes'])} pendiente(s).", resultado)
    db.commit()

    return {"caso_id": caso.id, "estado": caso.estado, **resultado}


@router.post("/{caso_id}/diligencia")
def registrar_diligencia(caso_id: int, payload: schemas.DiligenciaRequest, db: Session = Depends(get_db)):
    """HU2 (debida diligencia): registra el checklist KYC y cruza contra la lista de riesgo."""
    caso = _obtener_caso_o_404(db, caso_id)
    hay_riesgo, detalle_riesgo, _ = validations.validar_riesgo(db, caso.cliente)

    pendientes = []
    if not payload.identidad_ok:
        pendientes.append("identidad_no_verificada")
    if not payload.capacidad_legal_ok:
        pendientes.append("capacidad_legal_no_verificada")
    if caso.cliente.tipo_persona == "JURIDICA" and not payload.representacion_legal_ok:
        pendientes.append("representacion_legal_no_verificada")
    if not payload.kyc_formulario_ok:
        pendientes.append("formulario_kyc_incompleto")
    if not payload.origen_fondos_ok:
        pendientes.append("origen_fondos_no_justificado")
    if hay_riesgo:
        pendientes.append("coincidencia_lista_riesgo")

    resultado = "RECHAZADO" if (not payload.identidad_ok or not payload.capacidad_legal_ok) else ("PENDIENTE" if pendientes else "APROBADO")

    diligencia = caso.diligencia or models.DebidaDiligencia(caso_id=caso.id)
    diligencia.identidad_ok = payload.identidad_ok
    diligencia.capacidad_legal_ok = payload.capacidad_legal_ok
    diligencia.representacion_legal_ok = payload.representacion_legal_ok
    diligencia.beneficiario_final = payload.beneficiario_final
    diligencia.kyc_formulario_ok = payload.kyc_formulario_ok
    diligencia.origen_fondos_ok = payload.origen_fondos_ok
    diligencia.riesgo_match = hay_riesgo
    diligencia.riesgo_detalle = detalle_riesgo
    diligencia.resultado = resultado
    diligencia.pendientes_json = json.dumps(pendientes)
    db.add(diligencia)

    caso.estado = {"APROBADO": "DILIGENCIA_APROBADA", "PENDIENTE": "PENDIENTE_DOCUMENTO", "RECHAZADO": "RECHAZADO"}[resultado]
    caso.proxima_accion = {
        "APROBADO": "Continuar con validación de la nota (POST /casos/{id}/validar)",
        "PENDIENTE": "Falta un documento o actualización; completar checklist KYC",
        "RECHAZADO": "Caso rechazado en debida diligencia; requiere revisión de cumplimiento",
    }[resultado]

    _registrar_evento(db, caso, "DILIGENCIA", f"Debida diligencia: resultado {resultado}.", {"pendientes": pendientes, "riesgo": detalle_riesgo})
    db.commit()

    return {"caso_id": caso.id, "resultado": resultado, "pendientes": pendientes, "riesgo_detalle": detalle_riesgo}


@router.post("/{caso_id}/negociacion/propuesta")
def crear_propuesta(caso_id: int, payload: schemas.PropuestaRequest, db: Session = Depends(get_db)):
    """HU3: calcula la propuesta económica y genera un borrador para revisión del operador."""
    caso = _obtener_caso_o_404(db, caso_id)
    if caso.titulo is None:
        raise HTTPException(status_code=409, detail="El caso no tiene un título/nota de crédito asociado.")

    monto_base = payload.monto_a_retirar if payload.monto_a_retirar is not None else caso.titulo.saldo_disponible
    if monto_base > caso.titulo.saldo_disponible:
        raise HTTPException(status_code=400, detail="El monto a retirar excede el saldo disponible del título.")

    calculo = negociacion_service.calcular_propuesta(monto_base, payload.precio_negociacion_pct, payload.otros_costos)

    negociacion = models.Negociacion(
        caso_id=caso.id,
        vigencia_autorizacion=payload.vigencia_autorizacion,
        instrucciones_especiales=payload.instrucciones_especiales,
        cuenta_destino=payload.cuenta_destino,
        estado="BORRADOR",
        **calculo,
    )
    db.add(negociacion)
    db.flush()

    negociacion.borrador_texto = negociacion_service.generar_borrador(caso, caso.cliente, caso.titulo, negociacion)

    caso.estado = "EN_NEGOCIACION"
    caso.proxima_accion = "Revisar y aprobar el borrador de negociación (POST /casos/{id}/negociacion/{negociacion_id}/aprobar)"

    _registrar_evento(db, caso, "PROPUESTA", "Propuesta económica generada.", calculo)
    db.commit()
    db.refresh(negociacion)

    return negociacion_a_dict(negociacion)


@router.post("/{caso_id}/negociacion/{negociacion_id}/aprobar")
def aprobar_negociacion(caso_id: int, negociacion_id: int, db: Session = Depends(get_db)):
    caso = _obtener_caso_o_404(db, caso_id)
    negociacion = db.get(models.Negociacion, negociacion_id)
    if negociacion is None or negociacion.caso_id != caso.id:
        raise HTTPException(status_code=404, detail="Negociación no encontrada para este caso.")

    if negociacion.valor_nominal > caso.titulo.saldo_disponible:
        raise HTTPException(status_code=400, detail="Saldo insuficiente en el título para aprobar esta negociación.")

    caso.titulo.saldo_disponible -= negociacion.valor_nominal

    transaccion = models.Transaccion(
        cliente_id=caso.cliente_id,
        titulo_id=caso.titulo_id,
        caso_id=caso.id,
        negociacion_id=negociacion.id,
        ruc_cedula=caso.cliente.ruc_cedula,
        monto_retirado=negociacion.valor_nominal,
        saldo_restante=caso.titulo.saldo_disponible,
        tipo="RETIRO_NEGOCIACION"
    )
    db.add(transaccion)

    negociacion.estado = "APROBADA_OPERADOR"
    caso.estado = "NEGOCIACION_APROBADA"
    caso.proxima_accion = "Solicitar cierre (POST /casos/{id}/cierre) con aprobación humana para liquidación/transferencia/endoso"

    _registrar_evento(db, caso, "APROBACION", f"Operador aprobó la negociación #{negociacion.id}.")
    db.commit()

    return {"caso_id": caso.id, "negociacion_id": negociacion.id, "estado": negociacion.estado}


@router.post("/{caso_id}/cierre")
def solicitar_cierre(caso_id: int, payload: schemas.CierreRequest, db: Session = Depends(get_db)):
    """HU3: deja liquidación/transferencia/endoso como propuesta o alerta; no ejecuta nada regulado."""
    caso = _obtener_caso_o_404(db, caso_id)
    if payload.accion not in ACCIONES_CIERRE_VALIDAS:
        raise HTTPException(status_code=400, detail=f"accion debe ser una de: {sorted(ACCIONES_CIERRE_VALIDAS)}")

    caso.estado = "PENDIENTE_APROBACION_CIERRE"
    caso.proxima_accion = f"Solicitud de aprobación humana para ejecutar {payload.accion}. No se ejecuta automáticamente."
    if payload.observaciones:
        caso.observaciones = payload.observaciones

    _registrar_evento(
        db,
        caso,
        "SOLICITUD_APROBACION",
        f"Se solicita aprobación humana para {payload.accion}. Ninguna acción regulada fue ejecutada.",
        {"accion": payload.accion},
    )
    db.commit()

    return {
        "caso_id": caso.id,
        "estado": caso.estado,
        "accion_solicitada": payload.accion,
        "mensaje": "Queda registrada como propuesta/solicitud de aprobación. No se ejecuta en producción.",
    }
